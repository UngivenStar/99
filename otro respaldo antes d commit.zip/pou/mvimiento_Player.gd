extends CharacterBody2D

const SPEED = 300.0
const JUMP_VELOCITY = -400.0
const MAX_JUMPS = 2
var has_key: bool = false
@export var next_level_scene: String = "res://nivel2.1.tscn"
var jumps = 0

@onready var animationPlayer = $AnimationPlayer
@onready var sprite = $Sprite2D

@onready var detector = $Detector

func _ready():
	add_to_group("personaje")
	


func _physics_process(delta: float) -> void:
	# Agregar gravedad si no estamos en el suelo
	if not is_on_floor():
		velocity += get_gravity() * delta
	else:
		# Reiniciar los saltos al tocar el suelo
		jumps = 0

	# Manejo de salto (hasta dos saltos)
	if Input.is_action_just_pressed("ui_accept") and jumps < MAX_JUMPS:
		velocity.y = JUMP_VELOCITY
		jumps += 1

	# Movimiento horizontal
	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()



	# Animaciones
	animations(direction)

	# Flip del sprite
	if direction == 1:
		sprite.flip_h = false
	elif direction == -1:
		sprite.flip_h = true

func animations(direction):
	if is_on_floor():
		if direction == 0:
			animationPlayer.play("idle")
		else:
			animationPlayer.play("run")
	else:
		if velocity.y < 0:
			animationPlayer.play("jump")
		elif velocity.y > 0:
			animationPlayer.play("fall")


func _on_Detector_body_entered(body: Node2D) -> void:
	# 1) Picking up the key
	if body.is_in_group("Key") and not has_key:
		has_key = true
		body.queue_free()            # remove the key from the map
		# you can play a sound/animation here…

	# 2) Unlock the door if we have the key
	elif body.is_in_group("Door") and has_key:
		# you can play a door‐unlock animation here…
		get_tree().change_scene(next_level_scene)
